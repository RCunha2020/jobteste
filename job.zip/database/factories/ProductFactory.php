<?php

namespace Database\Factories;

use App\Models\Client;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition()
    {
        return  array(
            'name' => $this->faker->name(),
            'description' =>$this->faker->sentence($nbWords = 6, $variableNbWords = true),
            'price' => $this->faker->numberBetween(10,500),
            'sku' => $this->faker->ean13(),
            'stock'=> $this->faker->numberBetween(10,500),
            'client_id' => Client::factory()
        );
    }
}
