@extends('admin.dashboard')
@section('content')
  <main class="flex-shrink-0">
    <div class="container">
      <h1 class="mt-5">Cliente - <b>{{ $client->full_name ?? '' }}</h1>
      <p class="lead"><b>E-mail - {{ $client->email ?? '' }}</p>
        <p>Phone - <b>R$ {{ $client->phone ?? '' }}</b></p>
        <p><b>{{ $client->document_type ?? '' }}</b> - <b>{{ $client->document ?? '' }}</b></p>
        <p>Data do cadastro - <b>{{ $created_at ?? '' }}</b></p>
    </div>
  </main>
  
  <footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <a href="{{ URL::previous() }}">
            <button type="button" class="btn btn-secondary btn-sm">
                Voltar
            </button>
        </a>
    </div>
  </footer>
@endsection