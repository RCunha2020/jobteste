@extends('admin.dashboard')
@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Clientes</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="{{ route('clientnew') }}">
            <button type="button" class="btn btn-sm btn-outline-secondary ">
              <span data-feather="plus"></span>
              Novo
            </button>
          </a>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th>Id</th>
          <th>Nome</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Documento</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($clients as $c)
        <tr>
          <td>{{ $c->id }}</td>
          <td>{{ $c->full_name }}</td>
          <td>{{ $c->phone }}</td>
          <td>{{ $c->email }}</td>
          <td>{{ $c->document }}</td>
          <td>
            <a href="{{ url("client/$c->id/products") }}">
              <button type="button" class="btn btn-primary btn-sm">
                <span data-feather="shopping-cart"></span>
              </button>
            </a>
            <a href="{{ url("client/$c->id/view") }}">
              <button type="button" class="btn btn-secondary btn-sm">
                <span data-feather="eye"></span>
              </button>
            </a>
            <a href="{{ url("client/$c->id/edit") }}">
              <button type="button" class="btn btn-info btn-sm">
                <span data-feather="edit"></span>
              </button>
            </a>   
            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
              <span data-feather="trash"></span>
            </button>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">
        {{ $clients->links()}}
      </ul>
    </nav>
  </div>
  
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Atenção!</h5>
        </div>
        <div class="modal-body">
          Deseja excluir o cliente - <b>{{ $c->full_name ?? '' }}</b>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          @if (isset($c->id))
            <a href="{{ url("client/$c->id/destroy") }}">
              <button type="button" class="btn btn-danger">Excluir</button>
            </a>
          @endif

        </div>
      </div>
    </div>
  </div>
@endsection

