@extends('admin.dashboard')
@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">@if(isset($client))Editar Cliente @else Cadastrar Cliente @endif</h1>
</div>
@if(Session::has('message'))
  <div class="alert {{ Session::get('class') }} alert-dismissible fade show" role="alert">
    {{ Session::get('message') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
@endif

@if (isset($client))
  <form action="{{ route('clientupdate') }}" method="POST" novalidate>
    <input type="hidden" name="id" value="{{ $client->id ?? '' }}">
@else
  <form action="{{ route('clientsave') }}" method="POST" novalidate>
@endif
  @csrf
    <div class="row">
      <div class="form-group col-md-4">
        <label for="Nome">Nome</label>
        <input type="text" class="form-control" name="full_name" value="{{ $client->full_name ?? '' }}" placeholder="Nome completo">
        <span>@error('full_name')<span style="color:#f0200d">{{ $message }}</span>@enderror</span>
      </div>
      <div class="form-group col-md-4">
        <label for="inputAddress">Phone</label>
        <input type="text" class="form-control" name="phone" value="{{ $client->phone ?? '' }}" placeholder="Phone">
      </div>
    </div>
    <div class="row">
      <div class="form-group col-md-4">
        <label for="inputEmail4">Email</label>
        <input type="email" class="form-control" name="email" value="{{ $client->email ?? '' }}" placeholder="Email">
        @error('email')<span style="color:#f0200d">{{ $message }}</span>@enderror
      </div>
      <div class="form-group col-md-4">
        <label for="inputPassword4">Senha</label>
        <input type="password" class="form-control" name="password" placeholder="Mínimo 8 caracteres">
        @error('password')<span style="color:#f0200d">{{ $message }}</span>@enderror
      </div>
    </div>
    <div class="row">
      <div class="form-group col-md-4">
        <label>Tipo do Documento</label>
        <select id="document_type" class="form-control" name="document_type">
          @if(isset($client->document_type) && $client->document_type ==='CPF')
          <option value="CPF" selected>CPF</option>
          <option value="CNPJ">CNPJ</option>
          @else
          <option value="CPF">CPF</option>
          <option value="CNPJ" selected>CNPJ</option>
          @endif
        </select>
      </div>
      <div class="form-group col-md-4">
        <label>Documento</label>
        <input type="text" class="form-control" name="document" value="{{ $client->document ?? '' }}" placeholder="Número do cpf ou cnpj">
        @error('document')<span style="color:#f0200d">{{ $message }}</span>@enderror
      </div>
    </div>
    <div class="d-grid gap-2 d-md-block" style="margin-top:10px">
      <button class="btn btn-secondary" type="submit" >Salvar</button>
      <a class="btn btn-info" href="{{ route('clients') }}">Voltar</a>
    </div>
  </form>
  @endsection