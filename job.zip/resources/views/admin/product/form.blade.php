@extends('admin.dashboard')
@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">@if(isset($product))Editar Produto @else Cadastrar Produto @endif</h1>
</div>
@if(Session::has('message'))
  <div class="alert {{ Session::get('class') }} alert-dismissible fade show" role="alert">
    {{ Session::get('message') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
@endif

@if (isset($product))
  <form action="{{ route('productupdate') }}" method="POST" novalidate>
    <input type="hidden" name="id" value="{{ $product->id ?? '' }}">
@else
  <form action="{{ route('productsave') }}" method="POST" novalidate>
@endif
  @csrf
    <div class="row">
      <div class="form-group col-md-4">
        <label for="Nome">Nome</label>
        <input type="text" class="form-control" name="name" value="{{ $product->name ?? '' }}" placeholder="Nome do produto">
        <span>@error('name')<span style="color:#f0200d">{{ $message }}</span>@enderror</span>
      </div>
      <div class="form-group col-md-4">
        <label>Preço</label>
        <input type="text" class="form-control" name="price" value="{{ $product->price ?? '' }}" placeholder="Preço">
      </div>
      <div class="form-group col-md-4">
        <label>Código</label>
        <input type="text" class="form-control" name="sku" value="{{ $product->sku ?? '' }}" placeholder="Código de barras">
      </div>
      <div class="form-group col-md-12">
        <label for="inputAddress">Descrição</label>
        <input type="text" class="form-control" name="description" value="{{ $product->description ?? '' }}" placeholder="Descrição do produto">
      </div>
    </div>
    <div class="row">
      <div class="form-group col-md-4">
        <label>Cliente</label>
        <select id="document_type" class="form-control" name="client_id">
            @if (isset($product))
                @foreach ($clients as $c)
                    @if($product->client_id == $c->id)
                    <option value="{{ $c->id }}" selected>{{ $c->display_name }}</option>
                    @else
                    <option value="{{ $c->id }}">{{ $c->display_name }}</option>
                    @endif
                @endforeach
            @else
                <option value="" selected>Selecione o cliente</option>
                @foreach ($clients as $c)
                    <option value="{{ $c->id }}">{{ $c->display_name }}</option>
                @endforeach
            @endif
        </select>
        <span>@error('client_id')<span style="color:#f0200d">{{ $message }}</span>@enderror</span>
      </div>
      <div class="form-group col-md-4">
        <label>Estoque</label>
        <input type="text" class="form-control" name="stock" value="{{ $product->stock ?? '' }}" placeholder="Quantidade em estoque">
      </div>
    </div>
    <div class="d-grid gap-2 d-md-block" style="margin-top:10px">
      <button class="btn btn-secondary" type="submit" >Salvar</button>
      <a class="btn btn-info" href="{{ route('products') }}">Voltar</a>
    </div>
  </form>
  @endsection