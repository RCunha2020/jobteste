@extends('admin.dashboard')
@section('content')
  <main class="flex-shrink-0">
    <div class="container">
      <h1 class="mt-5">Produto - <b>{{ $product->name ?? '' }}</h1>
      <p class="lead"><b>Descrição - {{ $product->description ?? '' }}</p>
        <p>Preço - <b>R$ {{ $product->price ?? '' }}</b></p>
        <p>Sku - <b>{{ $product->sku ?? '' }}</b></p>
        <p>Estoque - <b>{{ $product->stock ?? '' }}</b></p>
        <p>Cliente - <b>{{ $client->full_name ?? '' }}</b></p>
        <p>Data do cadastro - <b>{{ $created_at ?? '' }}</b></p>
    </div>
  </main>
  
  <footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <a href="{{ URL::previous() }}">
            <button type="button" class="btn btn-secondary btn-sm">
                Voltar
            </button>
        </a>
    </div>
  </footer>
@endsection