<template lang="pt-br">
    <div>
        <h2>Bem vindo ao Inertia {{ nome }}</h2>
    </div>
</template>

<script>
    export default {
        props: {
            nome:String
        }
    }
</script>


