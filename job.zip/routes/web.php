<?php

use App\Http\Controllers\ClientController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;



Route::get('/',[HomeController::class,'dashboard'])->name('home');

Route::get('/products',[ProductController::class,'index'])->name('products');
Route::get('/productnew',[ProductController::class,'create'])->name('productnew');
Route::get('/product/{product}/view',[ProductController::class,'show'])->name('productview');
Route::post('/productsave',[ProductController::class,'store'])->name('productsave');
Route::get('/product/{product}/edit',[ProductController::class,'edit'])->name('productedit');
Route::post('/product/update',[ProductController::class,'update'])->name('productupdate');
Route::get('/product/{id}/destroy',[ProductController::class,'destroy'])->name('productdestroy');


Route::get('/clients',[ClientController::class,'index'])->name('clients');
Route::get('/clientnew',[ClientController::class,'create'])->name('clientnew');
Route::get('/client/{client}/view',[ClientController::class,'show'])->name('clientview');
Route::get('/client/{client}/products',[ClientController::class,'showProducts'])->name('clientproducts');
Route::post('/clientsave',[ClientController::class,'store'])->name('clientsave');
Route::get('/client/{id}/edit',[ClientController::class,'edit'])->name('clientedit');
Route::post('/client/update',[ClientController::class,'update'])->name('clientupdate');
Route::get('/client/{id}/destroy',[ClientController::class,'destroy'])->name('clientdestroy');


