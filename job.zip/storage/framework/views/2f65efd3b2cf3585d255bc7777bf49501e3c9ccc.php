
<?php $__env->startSection('content'); ?>
  <main class="flex-shrink-0">
    <div class="container">
      <h1 class="mt-5">Produto - <b><?php echo e($product->name ?? ''); ?></h1>
      <p class="lead"><b>Descrição - <?php echo e($product->description ?? ''); ?></p>
        <p>Preço - <b>R$ <?php echo e($product->price ?? ''); ?></b></p>
        <p>Sku - <b><?php echo e($product->sku ?? ''); ?></b></p>
        <p>Estoque - <b><?php echo e($product->stock ?? ''); ?></b></p>
        <p>Cliente - <b><?php echo e($client->full_name ?? ''); ?></b></p>
        <p>Data do cadastro - <b><?php echo e($created_at ?? ''); ?></b></p>
    </div>
  </main>
  
  <footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <a href="<?php echo e(URL::previous()); ?>">
            <button type="button" class="btn btn-secondary btn-sm">
                Voltar
            </button>
        </a>
    </div>
  </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobteste\resources\views/admin/product/view.blade.php ENDPATH**/ ?>