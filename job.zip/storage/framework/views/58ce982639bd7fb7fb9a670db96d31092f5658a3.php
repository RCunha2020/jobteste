
<?php $__env->startSection('content'); ?>
  <main class="flex-shrink-0">
    <div class="container">
      <h1 class="mt-5">Cliente - <b><?php echo e($client->full_name ?? ''); ?></h1>
      <p class="lead"><b>E-mail - <?php echo e($client->email ?? ''); ?></p>
        <p>Phone - <b>R$ <?php echo e($client->phone ?? ''); ?></b></p>
        <p><b><?php echo e($client->document_type ?? ''); ?></b> - <b><?php echo e($client->document ?? ''); ?></b></p>
        <p>Data do cadastro - <b><?php echo e($created_at ?? ''); ?></b></p>
    </div>
  </main>
  
  <footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <a href="<?php echo e(route('clients')); ?>">
            <button type="button" class="btn btn-secondary btn-sm">
                Voltar
            </button>
        </a>
    </div>
  </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobteste\resources\views/admin/client/view.blade.php ENDPATH**/ ?>