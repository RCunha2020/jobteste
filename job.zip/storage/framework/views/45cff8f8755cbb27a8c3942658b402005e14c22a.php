
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2"><?php if(isset($client)): ?>Editar Cliente <?php else: ?> Cadastrar Cliente <?php endif; ?></h1>
</div>
<?php if(Session::has('message')): ?>
  <div class="alert <?php echo e(Session::get('class')); ?> alert-dismissible fade show" role="alert">
    <?php echo e(Session::get('message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>

<?php if(isset($client)): ?>
  <form action="<?php echo e(route('clientupdate')); ?>" method="POST" novalidate>
    <input type="hidden" name="id" value="<?php echo e($client->id ?? ''); ?>">
<?php else: ?>
  <form action="<?php echo e(route('clientsave')); ?>" method="POST" novalidate>
<?php endif; ?>
  <?php echo csrf_field(); ?>
    <div class="row">
      <div class="form-group col-md-4">
        <label for="Nome">Nome</label>
        <input type="text" class="form-control" name="full_name" value="<?php echo e($client->full_name ?? ''); ?>" placeholder="Nome completo">
        <span><?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:#f0200d"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
      </div>
      <div class="form-group col-md-4">
        <label for="inputAddress">Phone</label>
        <input type="text" class="form-control" name="phone" value="<?php echo e($client->phone ?? ''); ?>" placeholder="Phone">
      </div>
    </div>
    <div class="row">
      <div class="form-group col-md-4">
        <label for="inputEmail4">Email</label>
        <input type="email" class="form-control" name="email" value="<?php echo e($client->email ?? ''); ?>" placeholder="Email">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:#f0200d"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-4">
        <label for="inputPassword4">Senha</label>
        <input type="password" class="form-control" name="password" placeholder="Mínimo 8 caracteres">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:#f0200d"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
    <div class="row">
      <div class="form-group col-md-4">
        <label>Tipo do Documento</label>
        <select id="document_type" class="form-control" name="document_type">
          <?php if(isset($client->document_type) && $client->document_type ==='CPF'): ?>
          <option value="CPF" selected>CPF</option>
          <option value="CNPJ">CNPJ</option>
          <?php else: ?>
          <option value="CPF">CPF</option>
          <option value="CNPJ" selected>CNPJ</option>
          <?php endif; ?>
        </select>
      </div>
      <div class="form-group col-md-4">
        <label>Documento</label>
        <input type="text" class="form-control" name="document" value="<?php echo e($client->document ?? ''); ?>" placeholder="Número do cpf ou cnpj">
        <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:#f0200d"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
    <div class="d-grid gap-2 d-md-block" style="margin-top:10px">
      <button class="btn btn-secondary" type="submit" >Salvar</button>
      <a class="btn btn-info" href="<?php echo e(route('clients')); ?>">Voltar</a>
    </div>
  </form>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobteste\resources\views/admin/client/form.blade.php ENDPATH**/ ?>