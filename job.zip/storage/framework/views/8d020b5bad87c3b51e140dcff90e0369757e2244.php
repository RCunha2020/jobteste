
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Produtos <?php if(isset($client)): ?><a href="<?php echo e(URL::previous()); ?>"><?php echo e($client->full_name); ?></a> <?php endif; ?></h1>
    <div class="btn-toolbar mb-2 mb-md-0">
      <a href="<?php echo e(url('/productnew')); ?>">
        <button type="button" class="btn btn-sm btn-outline-secondary ">
          <span data-feather="plus"></span>
          Novo
        </button>
      </a>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th>Id</th>
          <th>Nome</th>
          <th>Preço</th>
          <th>Sku</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($p->id); ?></td>
            <td><?php echo e($p->name); ?></td>
            <td><?php echo e($p->price); ?></td>
            <td><?php echo e($p->sku); ?></td>
            <td>
              <a href="<?php echo e(url("product/$p->id/view")); ?>">
                <button type="button" class="btn btn-secondary btn-sm">
                  <span data-feather="eye"></span>
                </button>
              </a>
              <a href="<?php echo e(url("product/$p->id/edit")); ?>">
                <button type="button" class="btn btn-info btn-sm">
                  <span data-feather="edit"></span>
                </button>
              </a>   
              <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <span data-feather="trash"></span>
              </button>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">
        <?php echo e($products->links()); ?>

      </ul>
    </nav>
  </div>

  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Atenção!</h5>
        </div>
        <div class="modal-body">
          Deseja excluir o produto - <b><?php echo e($p->name ?? ''); ?></b>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <?php if(isset($p->id)): ?>
            <a href="<?php echo e(url("product/$p->id/destroy")); ?>">
              <button type="button" class="btn btn-danger">Excluir</button>
            </a>
          <?php endif; ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobteste\resources\views/admin/product/index.blade.php ENDPATH**/ ?>