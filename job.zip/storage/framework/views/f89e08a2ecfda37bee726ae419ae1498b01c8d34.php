

<?php $__env->startSection('content'); ?>
<div class="container px-4 py-5" id="featured-3">
    <h2 class="pb-2 border-bottom">Informações</h2>
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
      <div class="feature col">
        <div class="feature-icon bg-primary bg-gradient">
          <span data-feather="shopping-cart" style="zoom:2"></span>
        </div>
        <h2>Produtos</h2>
        <h5>Cadastros - <?php echo e($total_products); ?></h5>
        <a href="<?php echo e(route('products')); ?>" class="icon-link">
          Lista de Produtos
          <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>
      <div class="feature col">
        <div class="feature-icon bg-primary bg-gradient">
          <span data-feather="users" style="zoom: 2"></span>
        </div>
        <h2>Clientes</h2>
        <h5>Cadastros - <?php echo e($total_clients); ?></h5>
        <a href="<?php echo e(route('clients')); ?>" class="icon-link">  
          Lista de Clientes
          <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobteste\resources\views/admin/home.blade.php ENDPATH**/ ?>