<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Blog-Vue</title>
</head>
<body>
    <div>
        <h1>Ola <?php echo e($nome); ?></h1>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\blogvue\resources\views/app.blade.php ENDPATH**/ ?>